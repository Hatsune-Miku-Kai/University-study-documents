#ifndef __KEY_H
#define __KEY_H

uint8_t Key_GetDoorMode(void);
void Key_Init(void);
uint8_t Key_GetRunMode(void);

#endif
