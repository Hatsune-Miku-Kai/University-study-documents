im=rgb2gray(imread('照片.jpg'));

noise_im=imnoise(im,'gaussian',0.002);

F=fspecial('gaussian',5,0.8);

new_im=imfilter(noise_im,F,'conv');

subplot(2,2,1),imshow(im);
title('原图');

subplot(2,2,2),imshow(noise_im);
title('添加噪声后的图片');

subplot(2,2,3),imshow(new_im);
title('滤波后的图');

